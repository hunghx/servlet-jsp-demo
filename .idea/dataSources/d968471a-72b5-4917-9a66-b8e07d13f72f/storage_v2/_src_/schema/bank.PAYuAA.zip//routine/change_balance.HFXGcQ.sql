create
    definer = root@localhost procedure change_balance(IN id_change int, IN money int)
begin
    update account set balance = balance+money where id = id_change;
end;

