create
    definer = root@localhost procedure send_money(IN id_sender int, IN id_receiver int, IN amount int)
begin
   START TRANSACTION ;
   SET AUTOCOMMIT = 0;
   update account set balance = balance + amount where id = id_receiver;
   update account set balance = balance - amount where id = id_sender;
   COMMIT ;
end;

