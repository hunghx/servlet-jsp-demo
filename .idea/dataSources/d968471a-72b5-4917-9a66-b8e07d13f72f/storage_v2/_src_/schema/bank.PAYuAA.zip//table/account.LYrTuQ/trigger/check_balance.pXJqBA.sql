create definer = root@localhost trigger check_balance
    before update
    on account
    for each row
begin
#         declare balance_current int default 0;
#         Select balance into balance_current from account where id = NEW.id;
        if NEW.balance < 0 then
           signal sqlstate '45000' set MESSAGE_TEXT = 'Tai khoan ko thể âm';
        end if ;
    end;

