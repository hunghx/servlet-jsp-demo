create definer = root@localhost trigger check_ter
    after insert
    on account
    for each row
begin
        if NEW.balance > 1000000 then
            signal sqlstate '45000' set message_text  = 'loi';
        end if;
    end;

