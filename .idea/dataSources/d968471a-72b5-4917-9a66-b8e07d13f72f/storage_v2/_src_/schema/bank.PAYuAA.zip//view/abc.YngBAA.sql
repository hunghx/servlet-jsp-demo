create definer = root@localhost view abc as
select `bank`.`account`.`id` AS `id`, `bank`.`account`.`name` AS `name`, `bank`.`account`.`balance` AS `balance`
from `bank`.`account`;

