create definer = root@localhost view abc1 as
select `bank`.`abc`.`id` AS `id`, `bank`.`abc`.`name` AS `name`, `bank`.`abc`.`balance` AS `balance`
from `bank`.`abc`;

