create
    definer = root@localhost procedure count_employee(OUT total int)
begin
    select count(*) into total from employee;
end;

