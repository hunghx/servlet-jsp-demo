create
    definer = root@localhost procedure insert_em(IN name_in varchar(45), IN dob_in date, IN sex_in bit,
                                                 IN avatar_in varchar(255))
begin
    insert into employee(name, dob, sex, avatar) value (name_in,dob_in,sex_in,avatar_in);
end;

